n = 2
str1 = input("Enter String For Operations:  ") 
#str1 = "khan"
print(  "----------------------------------------------------------------------------" )
print(str1.strip("!")) #this is used to remove multiple occurrences of a character or characters which are mistakenly added
print("-----------------")
print(len(str1)) #this is used to get length of string
print("-----------------")
print(str1.split()) #this is used to convert string to list
print("-----------------")