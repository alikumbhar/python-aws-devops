import os 

def mem_check(du): ###defining Functions
    return os.system("df")


def disk_usage(du):
    return os.system("du")

def check_date(dt):
    return os.system(dt)









##### CALLING FUNCTIONS HERE

print("MEMORY CHECK:")
print("--------------------------------------------------------------")

# print(os.system("df"))
mem_check("df")
print("--------------------------------------------------------------")
print ("DISK USAGE")
print("--------------------------------------------------------------")
disk_usage("du")

print("--------------------------------------------------------------")
print ("Date")
print("--------------------------------------------------------------")

check_date("date")

