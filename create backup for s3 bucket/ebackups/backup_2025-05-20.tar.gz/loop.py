import random
###### FOR loop portion
# i = 10
# for d in range(i):
#     print(d)


######while loop portion
# i = 0;
# while i < 5:

#     i += 1
#     print(i, "i has been added")
    # if i == 3:
    #     break
    # i += 1



num = 5

while num != 100:
    try:
        num = int(input("Enter Any Number to win gold: "))
    except ValueError:
        print("..")
    
    random_int = random.randint(1,4)
    if num == random_int:
        print(f"you win: {random_int} ")
    else:

        print ("Sorr! you lost, try again")
        print(f"Our Luck Draw Number is: {random_int} ")    


