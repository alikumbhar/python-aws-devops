from datetime import datetime
import os
list_of_hosting_provider = ["GCP", "Azure", "AWS", "Hostinger","Godaddy"]
print(list_of_hosting_provider)
list_of_hosting_provider.append("Contabo")
print("---------------")
list_of_hosting_provider.insert(3,"hosterpk")
print(list_of_hosting_provider)

for cloud_names in list_of_hosting_provider:
    print(cloud_names)

# app = ""
# while app != "stop":
#     app =  input(": ")
#     list_of_hosting_provider.append(app)
#     print(list_of_hosting_provider)
