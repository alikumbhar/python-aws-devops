
# in this code we will use condition operator in python

#ToDo List


days_of_week = input("Enter the Day of Week: ")

if days_of_week == 'sunday':
    print ("Today is sunday, Go Outside and enjoy")
    Q1 = input("Where you want to go. ? ")
    ls = ["karachi", "hyderabad","sukkur","lahore"]
    dv = ""
for item in ls:
    if item == "karachi":
        Q2 = input("where you want to go in karachi ? ")
        ls2 = ["kiamari","defence","gulshan"]
        for item2 in ls2:
            if item2 == "kiamari":
                print("you should must visit kiamaari")
            else:
                print("good job")


     # for Q1 in ls:
    #     print (ls)
 #   if Q1 == ls[Q1]:
#        print("you are going to ", ls[Q1])



