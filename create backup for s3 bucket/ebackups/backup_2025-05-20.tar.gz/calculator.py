first_number = int(input("Enter First Number: "))
second_number = int(input("Enter Second Number: "))
operator = input("Enter Operator: +, -, x, / ")

# by default data type is string 
# typecasting 

if operator == "+":
    print( first_number + second_number )
elif operator == "-":
    print( first_number - second_number )
elif operator == "/":
    print( first_number / second_number )
elif operator == "*":
    print( first_number * second_number )
else:
    print("nothing match")